"""Setup script for WiFi AC Guardian Windows Edition."""
from setuptools import setup, find_packages

setup(
    name="wifi-ac-guardian-win",
    version="1.0.0",
    description="Continuously ensures Wi-Fi is negotiated using Wi-Fi 5 (802.11ac) or higher on Windows 11.",
    author="Antigravity Engineering",
    packages=find_packages(),
    python_requires=">=3.10",
    install_requires=[
        "pystray>=0.19.5",
        "Pillow>=10.0.0",
    ],
    entry_points={
        "console_scripts": [
            "wifi-ac-guardian-win=wifi_ac_guardian_win.cli:main",
        ],
    },
)
