; Inno Setup Compiler Script for WiFi AC Guardian (Windows 11 Edition)
; Creates professional Setup.exe installer and unins000.exe uninstaller registered in Windows Add/Remove Programs.

[Setup]
AppId={{D37E8674-8A5B-4C91-9F22-4B6925A1654C}
AppName=WiFi AC Guardian
AppVersion=1.0.0
AppPublisher=Antigravity Engineering
AppPublisherURL=https://github.com/example/wifi-ac-guardian
AppSupportURL=https://github.com/example/wifi-ac-guardian
AppUpdatesURL=https://github.com/example/wifi-ac-guardian
DefaultDirName={autopf}\WiFi AC Guardian
DefaultGroupName=WiFi AC Guardian
DisableProgramGroupPage=yes
LicenseFile=README.md
OutputBaseFilename=WiFi_AC_Guardian_v1.0_Setup
Compression=lzma
SolidCompression=yes
WizardStyle=modern
UninstallDisplayIcon={app}\wifi-ac-guardian-win.exe
UninstallDisplayName=WiFi AC Guardian (Windows 11 Edition)

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"; Flags: unchecked
Name: "startupicon"; Description: "Automatically start protection on Windows login"; GroupDescription: "Startup Options:"

[Files]
Source: "dist\wifi-ac-guardian-win\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs igndir

[Icons]
Name: "{group}\WiFi AC Guardian Control Panel"; Filename: "{app}\wifi-ac-guardian-win.exe"; Parameters: "--gui"
Name: "{group}\Uninstall WiFi AC Guardian"; Filename: "{uninstallexe}"
Name: "{autodesktop}\WiFi AC Guardian"; Filename: "{app}\wifi-ac-guardian-win.exe"; Parameters: "--gui"; Tasks: desktopicon
Name: "{userstartup}\WiFi AC Guardian"; Filename: "{app}\wifi-ac-guardian-win.exe"; Parameters: "--daemon"; Tasks: startupicon

[Run]
Filename: "{app}\wifi-ac-guardian-win.exe"; Parameters: "--gui"; Description: "{cm:LaunchProgram,WiFi AC Guardian}"; Flags: nowait postinstall skipifsilent
