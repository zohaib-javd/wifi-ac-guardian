# WiFi AC Guardian (Windows 11 Edition) 🛡️📶

**WiFi AC Guardian (Windows 11 Edition)** is a native Python desktop application and background service designed specifically for Windows 11 systems. It continuously monitors the active WLAN connection's negotiated physical layer (PHY) mode via `netsh wlan show interfaces`. If the connection falls back to **Wi-Fi 4 (802.11n / HT)** or another slower mode, WiFi AC Guardian automatically disconnects and reconnects via `netsh wlan` until **Wi-Fi 5 (802.11ac / VHT)** or higher (**Wi-Fi 6 HE / Wi-Fi 7 EHT**) is established.

---

## 🌟 Key Features

- **Native Windows WLAN Integration**: Queries `netsh wlan show interfaces` and executes `netsh wlan disconnect` / `connect`.
- **Wi-Fi 5+ Protocol Enforcement**: Considers connection **GOOD** if Radio Type is:
  - **Wi-Fi 5** (`802.11ac` / `VHT`)
  - **Wi-Fi 6 / 6E** (`802.11ax` / `HE`)
  - **Wi-Fi 7** (`802.11be` / `EHT`)
- **Automated Downgrade Mitigation**:
  - Detects downgrade to Wi-Fi 4 (`802.11n`).
  - Logs warnings to `%USERPROFILE%\wifi_ac_guardian_win.log` with ISO timestamps.
  - Disconnects Wi-Fi interface, waits 2.0s, and reconnects.
  - Retries up to **10 attempts** with configurable backoff.
- **Windows Taskbar System Tray**:
  - Live color status icons (Green, Yellow, Red, Gray) in Windows 11 notification area.
  - Context menu for status summary, manual reconnect, pause/resume, and settings.
- **Native Tkinter Control Panel GUI**:
  - Requires **zero external GUI dependencies** on Windows 11.
  - Interactive sliders & spinboxes for **Check Interval (seconds)**, **Reconnection Delay (seconds)**, and **Max Reconnect Attempts**.
  - Checkboxes for **Enable Toast Notifications** and **Pause Protection**.
- **Windows Toast Notifications**: Native balloon/toast alerts via PowerShell.
- **Startup Integration**: Autostarts on Windows login via `%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\`.

---

## 📋 Requirements

- **OS**: Windows 11 (or Windows 10 64-bit)
- **Python**: Python 3.10 or newer (from python.org or Microsoft Store)
- **WLAN Card**: Any 802.11ac / 802.11ax / 802.11be Wi-Fi adapter

---

## 🚀 Installation & Usage

### 1. Installation
Run `install.bat` as Administrator or double-click to install:

```cmd
install.bat
```

The installer will:
1. Install the `wifi-ac-guardian-win` Python package.
2. Create a **Desktop Shortcut** (`WiFi AC Guardian.lnk`).
3. Add a **Windows Startup shortcut** for automated background monitoring.
4. Launch the Control Panel window.

### 2. CLI Usage

```cmd
:: Launch Graphical Control Panel UI
wifi-ac-guardian-win --gui

:: Show Instant Connection Status Report
wifi-ac-guardian-win --status

:: Run Continuous Background Monitoring Daemon
wifi-ac-guardian-win --daemon
```

**Status Report Output Example:**
```text
==================================================
    WiFi AC Guardian (Windows 11 Edition)        
==================================================
Interface:    Wi-Fi
Current SSID: HomeNetwork5G
Radio Type:   802.11ac
Frequency:    5805 MHz
Channel:      161
Signal:       95%
PHY Mode:     802.11ac (Wi-Fi 5)
Bitrate:      866.7 Mbps
Attempts:     0
Status:       GOOD (Wi-Fi 5+)
==================================================
```

### 3. Unit Tests

```cmd
python -m unittest discover -s tests -p "test_*.py"
```

---

## 🗑️ Uninstallation

Run `uninstall.bat` to remove startup entries, desktop shortcuts, and the Python package:

```cmd
uninstall.bat
```
