# PowerShell Installer & Windows Control Panel Add/Remove Programs Register Script
# Registers WiFi AC Guardian in Windows 11 Settings -> Apps -> Installed Apps (Add/Remove Programs)

param(
    [string]$InstallDir = "$env:LOCALAPPDATA\Programs\WiFi AC Guardian"
)

echo "=========================================================="
echo " Registering WiFi AC Guardian in Windows Add/Remove Programs"
echo "=========================================================="

New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null

# Copy application files
Copy-Item -Recurse -Force -Path "$PSScriptRoot\wifi_ac_guardian_win" -Destination "$InstallDir\"
Copy-Item -Force -Path "$PSScriptRoot\README.md" -Destination "$InstallDir\"

# Create PowerShell Uninstaller Script
$UninstallScript = "$InstallDir\uninstall_clean.ps1"
@'
param()
echo "Uninstalling WiFi AC Guardian..."
$InstallDir = Split-Path -Parent $MyInvocation.MyCommand.Path

# Remove Start Menu and Desktop Shortcuts
Remove-Item -Force "$env:APPDATA\Microsoft\Windows\Start Menu\Programs\Startup\WiFi AC Guardian.lnk" -ErrorAction SilentlyContinue
Remove-Item -Force "$env:USERPROFILE\Desktop\WiFi AC Guardian.lnk" -ErrorAction SilentlyContinue
Remove-Item -Recurse -Force "$env:APPDATA\Microsoft\Windows\Start Menu\Programs\WiFi AC Guardian" -ErrorAction SilentlyContinue

# Remove Registry Entry
Remove-Item -Recurse -Force "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\WiFiACGuardian" -ErrorAction SilentlyContinue

# Remove Installation Directory
Remove-Item -Recurse -Force $InstallDir -ErrorAction SilentlyContinue
echo "WiFi AC Guardian successfully uninstalled."
'@ | Out-File -Encoding UTF8 $UninstallScript

# Write Windows Add/Remove Programs Registry Key
$RegPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\WiFiACGuardian"
New-Item -Path $RegPath -Force | Out-Null
Set-ItemProperty -Path $RegPath -Name "DisplayName" -Value "WiFi AC Guardian (Windows 11 Edition)"
Set-ItemProperty -Path $RegPath -Name "DisplayVersion" -Value "1.0.0"
Set-ItemProperty -Path $RegPath -Name "Publisher" -Value "Antigravity Engineering"
Set-ItemProperty -Path $RegPath -Name "UninstallString" -Value "powershell.exe -ExecutionPolicy Bypass -File `"$UninstallScript`""
Set-ItemProperty -Path $RegPath -Name "InstallLocation" -Value $InstallDir
Set-ItemProperty -Path $RegPath -Name "NoModify" -Value 1
Set-ItemProperty -Path $RegPath -Name "NoRepair" -Value 1

echo "Successfully registered in Windows 11 Apps & Features!"
