"""
Configuration manager for WiFi AC Guardian Windows Edition.
"""

import os
import json
from typing import Optional
from wifi_ac_guardian_win.core.models import GuardianConfig
from wifi_ac_guardian_win.logger import get_logger

logger = get_logger()

CONFIG_DIR = os.path.expanduser("~/.config/wifi-ac-guardian-win")
CONFIG_FILE = os.path.join(CONFIG_DIR, "config.json")


def load_config(config_path: Optional[str] = None) -> GuardianConfig:
    target_path = os.path.expanduser(config_path) if config_path else CONFIG_FILE

    if os.path.exists(target_path):
        try:
            with open(target_path, "r", encoding="utf-8") as f:
                data = json.load(f)

            return GuardianConfig(
                interface=data.get("interface", "Wi-Fi"),
                check_interval=float(data.get("check_interval", 10.0)),
                reconnect_delay=float(data.get("reconnect_delay", 2.0)),
                max_attempts=int(data.get("max_attempts", 10)),
                log_file_path=data.get("log_file_path", os.path.join(os.path.expanduser("~"), "wifi_ac_guardian_win.log")),
                enable_notifications=bool(data.get("enable_notifications", False)),
                enable_tray=bool(data.get("enable_tray", True)),
                is_paused=bool(data.get("is_paused", False)),
            )
        except Exception as e:
            logger.warning(f"Error loading config: {e}. Using defaults.")

    return GuardianConfig()


def save_config(config: GuardianConfig, config_path: Optional[str] = None) -> str:
    target_path = os.path.expanduser(config_path) if config_path else CONFIG_FILE
    os.makedirs(os.path.dirname(target_path), exist_ok=True)

    data = {
        "interface": config.interface,
        "check_interval": config.check_interval,
        "reconnect_delay": config.reconnect_delay,
        "max_attempts": config.max_attempts,
        "log_file_path": config.log_file_path,
        "enable_notifications": config.enable_notifications,
        "enable_tray": config.enable_tray,
        "is_paused": config.is_paused,
    }

    with open(target_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4)

    return target_path
