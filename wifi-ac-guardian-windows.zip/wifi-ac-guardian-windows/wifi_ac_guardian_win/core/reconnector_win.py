"""
Windows WLAN reconnection handler for Wi-Fi AC Guardian using netsh wlan.
"""

import time
import subprocess
from typing import Optional
from wifi_ac_guardian_win.core.models import LinkInfo, GuardianConfig
from wifi_ac_guardian_win.core.detector_win import WifiDetectorWin
from wifi_ac_guardian_win.logger import get_logger

logger = get_logger()


class WifiReconnectorWin:
    """Manages netsh wlan Wi-Fi disconnection and reconnection routines on Windows 11."""

    def __init__(self, config: Optional[GuardianConfig] = None):
        self.config = config or GuardianConfig()
        self.detector = WifiDetectorWin(interface=self.config.interface)

    def trigger_reconnect(self, interface: str = "Wi-Fi", ssid: Optional[str] = None) -> LinkInfo:
        """
        Executes disconnect, delay, reconnect sequence via netsh wlan,
        then waits until interface re-connects and returns updated LinkInfo.
        """
        logger.warning(
            f"Triggering Wi-Fi reconnection on Windows interface '{interface}' "
            f"(Target SSID: '{ssid or 'Auto'}')..."
        )

        # 1. Disconnect interface
        self._disconnect_interface(interface)

        # 2. Wait reconnect_delay seconds (default 2.0s)
        delay = max(0.5, self.config.reconnect_delay)
        logger.info(f"Waiting {delay:.1f} seconds before reconnecting...")
        time.sleep(delay)

        # 3. Connect via netsh wlan
        self._connect_interface(interface, ssid)

        # 4. Wait until connected and verify PHY mode
        updated_link = self._wait_for_connection(interface, timeout_seconds=15)
        return updated_link

    def _disconnect_interface(self, interface: str) -> bool:
        """Disconnects Wi-Fi using netsh wlan disconnect."""
        logger.info(f"Disconnecting Wi-Fi interface {interface} via netsh...")
        try:
            cmd = ["netsh", "wlan", "disconnect", f"interface={interface}"]
            res = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
            if res.returncode == 0:
                logger.info(f"Successfully disconnected interface {interface}.")
                return True
            else:
                logger.warning(f"netsh disconnect returned output: {res.stdout or res.stderr}")
        except Exception as e:
            logger.error(f"Error disconnecting interface {interface}: {e}")
        return False

    def _connect_interface(self, interface: str, ssid: Optional[str] = None) -> bool:
        """Reconnects Wi-Fi using netsh wlan connect."""
        logger.info(f"Initiating Wi-Fi connection on {interface}...")

        cmd = ["netsh", "wlan", "connect"]
        if ssid:
            cmd.append(f"name={ssid}")
        cmd.append(f"interface={interface}")

        logger.info(f"Running command: {' '.join(cmd)}")
        try:
            res = subprocess.run(cmd, capture_output=True, text=True, timeout=15)
            if res.returncode == 0:
                logger.info(f"netsh connect succeeded for SSID '{ssid or 'Auto'}'.")
                return True
            else:
                logger.warning(f"netsh connect output: {res.stdout or res.stderr}")
        except Exception as e:
            logger.error(f"Error connecting device {interface}: {e}")

        return False

    def _wait_for_connection(self, interface: str, timeout_seconds: float = 15.0) -> LinkInfo:
        """Polls netsh wlan show interfaces until connection is established or timeout."""
        start_time = time.time()
        poll_interval = 1.0

        link_info = self.detector.get_link_info()

        while time.time() - start_time < timeout_seconds:
            if link_info.connected:
                logger.info(
                    f"Connection re-established on Windows interface '{interface}'! "
                    f"SSID: '{link_info.ssid}' | PHY Mode: {link_info.phy_summary}"
                )
                return link_info

            time.sleep(poll_interval)
            link_info = self.detector.get_link_info()

        logger.warning(f"Timed out waiting for Wi-Fi connection state stabilization on {interface}.")
        return link_info
