"""
Main monitoring engine for WiFi AC Guardian Windows Edition.
"""

import time
import signal
import threading
from datetime import datetime
from typing import Optional
from wifi_ac_guardian_win.core.models import (
    GuardianConfig,
    GuardianState,
    StatusState,
    LinkInfo,
)
from wifi_ac_guardian_win.core.detector_win import WifiDetectorWin
from wifi_ac_guardian_win.core.reconnector_win import WifiReconnectorWin
from wifi_ac_guardian_win.core.notifier_win import WindowsNotifier
from wifi_ac_guardian_win.tray import SystemTrayAppWin
from wifi_ac_guardian_win.logger import get_logger, setup_logger

logger = get_logger()


class WifiACGuardianWin:
    """Core monitoring engine for Windows 11."""

    def __init__(self, config: Optional[GuardianConfig] = None):
        self.config = config or GuardianConfig()
        setup_logger(log_file_path=self.config.log_file_path)

        self.detector = WifiDetectorWin(interface=self.config.interface)
        self.reconnector = WifiReconnectorWin(config=self.config)
        self.notifier = WindowsNotifier(enabled=self.config.enable_notifications)
        self.state = GuardianState()

        self.stop_event = threading.Event()
        self._lock = threading.Lock()

        self.tray_app: Optional[SystemTrayAppWin] = None
        if self.config.enable_tray:
            self.tray_app = SystemTrayAppWin(
                on_reconnect_click=self.force_reconnect,
                on_quit_click=self.stop,
                config=self.config
            )

    def force_reconnect(self) -> None:
        logger.info("Manual reconnection requested on Windows.")
        threading.Thread(target=self._execute_reconnection_sequence, daemon=True).start()

    def start(self) -> None:
        logger.info("==================================================")
        logger.info("  WiFi AC Guardian (Windows 11 Edition) Starting  ")
        logger.info("==================================================")
        logger.info(f"Target Interface: {self.config.interface or 'Wi-Fi'}")
        logger.info(f"Check Interval:   {self.config.check_interval:.1f}s")
        logger.info(f"Reconnect Delay:  {self.config.reconnect_delay:.1f}s")
        logger.info(f"Max Attempts:     {self.config.max_attempts}")
        logger.info("==================================================")

        self.state.running = True

        try:
            signal.signal(signal.SIGINT, self._handle_signal)
            signal.signal(signal.SIGTERM, self._handle_signal)
        except (ValueError, TypeError):
            pass

        if self.tray_app:
            self.tray_app.start()

        self._run_loop()

    def stop(self) -> None:
        logger.info("Stopping WiFi AC Guardian service...")
        self.state.running = False
        self.stop_event.set()

        if self.tray_app:
            self.tray_app.stop()

        logger.info("WiFi AC Guardian stopped cleanly.")

    def _handle_signal(self, signum: int, frame: object) -> None:
        self.stop()

    def _run_loop(self) -> None:
        self.perform_check()

        while not self.stop_event.is_set():
            if self.stop_event.wait(timeout=self.config.check_interval):
                break

            self.perform_check()

    def perform_check(self) -> LinkInfo:
        with self._lock:
            self.state.last_check = datetime.now()
            link = self.detector.get_link_info()
            self.state.current_link = link

            if not link.connected:
                logger.info("Windows Wi-Fi state: Disconnected.")
                self._set_status(StatusState.DISCONNECTED, link)
                return link

            logger.info(
                f"Windows Wi-Fi state on {link.interface}: SSID='{link.ssid}' | "
                f"Radio='{link.radio_type}' | PHY Mode={link.phy_summary} | "
                f"Signal={link.signal_pct}%"
            )

            if link.is_good:
                logger.info(f"Connection quality is GOOD ({link.phy_summary}). Resetting retry counter.")
                self.state.attempts_count = 0
                self._set_status(StatusState.GOOD, link)
                return link

            if self.config.is_paused:
                logger.info("Reconnection protection is PAUSED by user.")
                self._set_status(StatusState.IDLE, link)
                return link

            logger.warning(
                f"[WARNING] Windows Wi-Fi connection downgraded to lower PHY mode: {link.phy_summary}. "
                "Wi-Fi 5 (802.11ac) or higher is required."
            )

            if self.state.attempts_count >= self.config.max_attempts:
                logger.error(f"Reached maximum reconnection attempts ({self.config.max_attempts}).")
                self._set_status(StatusState.FAILED, link)
                return link

            self._execute_reconnection_sequence()
            return self.state.current_link

    def _execute_reconnection_sequence(self) -> None:
        link = self.state.current_link or self.detector.get_link_info()
        interface = link.interface or "Wi-Fi"
        ssid = link.ssid

        self.state.attempts_count += 1
        current_attempt = self.state.attempts_count

        logger.warning(
            f"Attempt {current_attempt}/{self.config.max_attempts}: "
            f"Disconnecting and reconnecting Wi-Fi on Windows interface '{interface}'..."
        )

        self._set_status(StatusState.RETRYING, link)
        self.state.last_reconnect = datetime.now()

        updated_link = self.reconnector.trigger_reconnect(interface, ssid=ssid)
        self.state.current_link = updated_link

        if updated_link.is_good:
            logger.info(f"Reconnection successful! Re-established {updated_link.phy_summary}.")
            self.state.attempts_count = 0
            self._set_status(StatusState.GOOD, updated_link)
        else:
            if current_attempt >= self.config.max_attempts:
                self._set_status(StatusState.FAILED, updated_link)
            else:
                self._set_status(StatusState.RETRYING, updated_link)

    def _set_status(self, status: StatusState, link: Optional[LinkInfo] = None) -> None:
        self.state.status = status
        self.notifier.notify_status(
            status=status,
            link=link,
            attempts=self.state.attempts_count,
            max_attempts=self.config.max_attempts
        )
        if self.tray_app:
            self.tray_app.update_status(status, link)
