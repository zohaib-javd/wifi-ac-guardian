"""
System tray interface for Windows 11.
"""

import os
import subprocess
import threading
from typing import Optional, Callable
from wifi_ac_guardian_win.core.models import StatusState, LinkInfo, GuardianConfig
from wifi_ac_guardian_win.icons import create_pillow_icon_for_state
from wifi_ac_guardian_win.logger import get_logger

logger = get_logger()

PYSTRAY_AVAILABLE = False
try:
    import pystray
    from pystray import MenuItem as item, Menu
    PYSTRAY_AVAILABLE = True
except Exception as e:
    PYSTRAY_AVAILABLE = False


class SystemTrayAppWin:
    """Manages system tray icon and menu on Windows 11 taskbar."""

    def __init__(
        self,
        on_reconnect_click: Optional[Callable[[], None]] = None,
        on_quit_click: Optional[Callable[[], None]] = None,
        config: Optional[GuardianConfig] = None
    ):
        self.on_reconnect_click = on_reconnect_click
        self.on_quit_click = on_quit_click
        self.config = config or GuardianConfig()
        self.current_state = StatusState.IDLE
        self.current_link: Optional[LinkInfo] = None
        self.icon_instance: Optional[object] = None
        self._thread: Optional[threading.Thread] = None

    def start(self) -> None:
        if not PYSTRAY_AVAILABLE:
            logger.info("pystray not available. Tray applet disabled.")
            return

        self._thread = threading.Thread(target=self._run_tray, daemon=True, name="WinTrayThread")
        self._thread.start()

    def _run_tray(self) -> None:
        try:
            initial_image = create_pillow_icon_for_state(self.current_state)
            menu = Menu(
                item(self._get_status_text, None, enabled=False),
                item(self._get_phy_text, None, enabled=False),
                Menu.SEPARATOR,
                item("🔄 Reconnect Now", self._handle_reconnect),
                item(self._get_pause_text, self._handle_toggle_pause),
                item(self._get_notify_text, self._handle_toggle_notify),
                item("⚙️ Open Control Panel", self._handle_open_ui),
                Menu.SEPARATOR,
                item("🛑 Stop & Exit", self._handle_quit),
            )

            self.icon_instance = pystray.Icon(
                "wifi_ac_guardian_win",
                initial_image,
                "WiFi AC Guardian (Windows 11)",
                menu
            )
            self.icon_instance.run()
        except Exception as e:
            logger.error(f"Error running Windows system tray icon: {e}")

    def _get_status_text(self, item_obj=None) -> str:
        state_str = self.current_state.value
        if self.config.is_paused:
            return "Status: PAUSED"
        if self.current_link and self.current_link.ssid:
            return f"Status: {state_str} ({self.current_link.ssid})"
        return f"Status: {state_str}"

    def _get_phy_text(self, item_obj=None) -> str:
        if self.current_link and self.current_link.connected:
            return f"Mode: {self.current_link.phy_summary}"
        return "Mode: Disconnected"

    def _get_pause_text(self, item_obj=None) -> str:
        return "▶️ Resume Protection" if self.config.is_paused else "⏸️ Pause Protection"

    def _get_notify_text(self, item_obj=None) -> str:
        return "🔕 Notifications: OFF" if not self.config.enable_notifications else "🔔 Notifications: ON"

    def _handle_reconnect(self, icon=None, item_obj=None) -> None:
        if self.on_reconnect_click:
            self.on_reconnect_click()

    def _handle_toggle_pause(self, icon=None, item_obj=None) -> None:
        self.config.is_paused = not self.config.is_paused
        if self.icon_instance:
            self.icon_instance.update_menu()

    def _handle_toggle_notify(self, icon=None, item_obj=None) -> None:
        self.config.enable_notifications = not self.config.enable_notifications
        if self.icon_instance:
            self.icon_instance.update_menu()

    def _handle_open_ui(self, icon=None, item_obj=None) -> None:
        try:
            subprocess.Popen(["wifi-ac-guardian-win", "--gui"])
        except Exception:
            pass

    def _handle_quit(self, icon=None, item_obj=None) -> None:
        self.stop()
        if self.on_quit_click:
            self.on_quit_click()

    def update_status(self, state: StatusState, link: Optional[LinkInfo] = None) -> None:
        self.current_state = state
        self.current_link = link

        if not self.icon_instance or not PYSTRAY_AVAILABLE:
            return

        try:
            new_image = create_pillow_icon_for_state(state)
            self.icon_instance.icon = new_image

            if link and link.connected:
                title = f"WiFi AC Guardian: {link.phy_summary} ({link.ssid})"
            else:
                title = f"WiFi AC Guardian: {state.value}"
            self.icon_instance.title = title
        except Exception:
            pass

    def stop(self) -> None:
        if self.icon_instance and PYSTRAY_AVAILABLE:
            try:
                self.icon_instance.stop()
            except Exception:
                pass
