"""
Tkinter Control Panel GUI for WiFi AC Guardian Windows Edition.
Requires zero third-party GUI dependencies on Windows 11.
"""

import os
import sys
import threading
import tkinter as tk
from tkinter import ttk, messagebox
from typing import Optional

from wifi_ac_guardian_win.core.models import GuardianConfig, StatusState, LinkInfo
from wifi_ac_guardian_win.core.detector_win import WifiDetectorWin
from wifi_ac_guardian_win.core.reconnector_win import WifiReconnectorWin
from wifi_ac_guardian_win.config import load_config, save_config
from wifi_ac_guardian_win.logger import get_logger

logger = get_logger()


class WifiACGuardianWinUI(tk.Tk):
    """Tkinter Desktop Window for Windows 11."""

    def __init__(self, config: Optional[GuardianConfig] = None):
        super().__init__()
        self.title("WiFi AC Guardian (Windows 11 Edition)")
        self.geometry("520x640")
        self.resizable(False, False)
        self.configure(bg="#1E1E2E")

        self.config = config or load_config()
        self.detector = WifiDetectorWin(interface=self.config.interface)
        self.reconnector = WifiReconnectorWin(config=self.config)

        self._build_ui()
        self._refresh_status()

    def _build_ui(self) -> None:
        # Title Header
        lbl_title = tk.Label(
            self,
            text="🛡️ WiFi AC Guardian (Windows 11)",
            font=("Segoe UI", 16, "bold"),
            fg="#F5E0DC",
            bg="#1E1E2E"
        )
        lbl_title.pack(pady=12)

        # Status Card Frame
        self.card_frame = tk.Frame(self, bg="#11111B", highlightbackground="#A6E3A1", highlightthickness=2)
        self.card_frame.pack(fill="x", padx=18, pady=8)

        self.lbl_badge = tk.Label(
            self.card_frame,
            text="GOOD (Wi-Fi 5+)",
            font=("Segoe UI", 12, "bold"),
            fg="#11111B",
            bg="#A6E3A1",
            padx=10,
            pady=4
        )
        self.lbl_badge.pack(anchor="w", padx=12, pady=8)

        self.lbl_ssid = tk.Label(
            self.card_frame,
            text="SSID: Detecting...",
            font=("Segoe UI", 11),
            fg="#CDD6F4",
            bg="#11111B"
        )
        self.lbl_ssid.pack(anchor="w", padx=12, pady=2)

        self.lbl_phy = tk.Label(
            self.card_frame,
            text="PHY Mode: -",
            font=("Segoe UI", 10),
            fg="#89B4FA",
            bg="#11111B"
        )
        self.lbl_phy.pack(anchor="w", padx=12, pady=2)

        self.lbl_details = tk.Label(
            self.card_frame,
            text="Bitrate: - | Signal: - | Interface: Wi-Fi",
            font=("Segoe UI", 9),
            fg="#A6ADC8",
            bg="#11111B"
        )
        self.lbl_details.pack(anchor="w", padx=12, pady=8)

        # Controls Section
        lbl_sec = tk.Label(
            self,
            text="⚙️ Timing & Reattempt Controls",
            font=("Segoe UI", 12, "bold"),
            fg="#CBA6F7",
            bg="#1E1E2E"
        )
        lbl_sec.pack(anchor="w", padx=18, pady=(16, 4))

        ctrl_frame = tk.Frame(self, bg="#181825", bd=1, relief="solid")
        ctrl_frame.pack(fill="x", padx=18, pady=4)

        # Check Interval
        lbl_int = tk.Label(ctrl_frame, text="Check Interval (seconds):", fg="#CDD6F4", bg="#181825")
        lbl_int.pack(anchor="w", padx=12, pady=(10, 2))

        self.var_interval = tk.DoubleVar(value=self.config.check_interval)
        scale_int = tk.Scale(
            ctrl_frame,
            from_=2.0,
            to=60.0,
            resolution=1.0,
            orient="horizontal",
            variable=self.var_interval,
            bg="#181825",
            fg="#CDD6F4",
            highlightthickness=0
        )
        scale_int.pack(fill="x", padx=12, pady=2)

        # Reconnect Delay
        lbl_delay = tk.Label(ctrl_frame, text="Reconnection Delay (seconds):", fg="#CDD6F4", bg="#181825")
        lbl_delay.pack(anchor="w", padx=12, pady=(6, 2))

        self.var_delay = tk.DoubleVar(value=self.config.reconnect_delay)
        scale_delay = tk.Scale(
            ctrl_frame,
            from_=0.5,
            to=10.0,
            resolution=0.5,
            orient="horizontal",
            variable=self.var_delay,
            bg="#181825",
            fg="#CDD6F4",
            highlightthickness=0
        )
        scale_delay.pack(fill="x", padx=12, pady=2)

        # Max Attempts
        lbl_max = tk.Label(ctrl_frame, text="Max Reconnect Attempts:", fg="#CDD6F4", bg="#181825")
        lbl_max.pack(anchor="w", padx=12, pady=(6, 2))

        self.var_max = tk.IntVar(value=self.config.max_attempts)
        spin_max = tk.Spinbox(
            ctrl_frame,
            from_=1,
            to=20,
            textvariable=self.var_max,
            bg="#313244",
            fg="#CDD6F4"
        )
        spin_max.pack(anchor="w", padx=12, pady=4)

        # Checkboxes
        self.var_notify = tk.BooleanVar(value=self.config.enable_notifications)
        chk_notify = tk.Checkbutton(
            ctrl_frame,
            text="Enable Toast Notification Popups",
            variable=self.var_notify,
            bg="#181825",
            fg="#CDD6F4",
            selectcolor="#313244"
        )
        chk_notify.pack(anchor="w", padx=12, pady=4)

        self.var_pause = tk.BooleanVar(value=self.config.is_paused)
        chk_pause = tk.Checkbutton(
            ctrl_frame,
            text="Pause Automatic Reconnection Protection",
            variable=self.var_pause,
            bg="#181825",
            fg="#CDD6F4",
            selectcolor="#313244"
        )
        chk_pause.pack(anchor="w", padx=12, pady=6)

        # Save Button
        btn_save = tk.Button(
            ctrl_frame,
            text="💾 Save Settings",
            command=self._save_settings,
            bg="#313244",
            fg="#CDD6F4",
            font=("Segoe UI", 10, "bold")
        )
        btn_save.pack(fill="x", padx=12, pady=10)

        # Action Buttons
        btn_box = tk.Frame(self, bg="#1E1E2E")
        btn_box.pack(fill="x", padx=18, pady=16)

        btn_reconnect = tk.Button(
            btn_box,
            text="🔄 Reconnect Now",
            command=self._on_reconnect,
            bg="#89B4FA",
            fg="#11111B",
            font=("Segoe UI", 10, "bold")
        )
        btn_reconnect.pack(side="left", fill="x", expand=True, mr=4 if hasattr(tk, 'mr') else 0)

    def _refresh_status(self) -> None:
        def worker():
            link = self.detector.get_link_info()
            self.after(0, self._update_ui, link)

        threading.Thread(target=worker, daemon=True).start()
        self.after(2000, self._refresh_status)

    def _update_ui(self, link: LinkInfo) -> None:
        if not link.connected:
            self.card_frame.configure(highlightbackground="#F38BA8")
            self.lbl_badge.configure(text="DISCONNECTED", bg="#F38BA8", fg="#11111B")
            self.lbl_ssid.configure(text="SSID: Disconnected")
            self.lbl_phy.configure(text="PHY Mode: Disconnected")
            self.lbl_details.configure(text="N/A")
            return

        self.lbl_ssid.configure(text=f"SSID: {link.ssid or 'Unknown'}")
        self.lbl_phy.configure(text=f"PHY Mode: {link.phy_summary}")

        sig_txt = f"{link.signal_pct}%" if link.signal_pct is not None else "N/A"
        bitrate_txt = link.tx_bitrate or "N/A"
        self.lbl_details.configure(text=f"Bitrate: {bitrate_txt} | Signal: {sig_txt} | Interface: {link.interface}")

        if link.is_good:
            self.card_frame.configure(highlightbackground="#A6E3A1")
            self.lbl_badge.configure(text="GOOD (Wi-Fi 5+)", bg="#A6E3A1", fg="#11111B")
        else:
            self.card_frame.configure(highlightbackground="#F9E2AF")
            self.lbl_badge.configure(text="Wi-Fi 4 DOWNGRADE", bg="#F9E2AF", fg="#11111B")

    def _save_settings(self) -> None:
        self.config.check_interval = self.var_interval.get()
        self.config.reconnect_delay = self.var_delay.get()
        self.config.max_attempts = self.var_max.get()
        self.config.enable_notifications = self.var_notify.get()
        self.config.is_paused = self.var_pause.get()

        path = save_config(self.config)
        messagebox.showinfo("Settings Saved", f"Configuration saved successfully to {path}")

    def _on_reconnect(self) -> None:
        def worker():
            link = self.detector.get_link_info()
            self.reconnector.trigger_reconnect(link.interface, ssid=link.ssid)

        threading.Thread(target=worker, daemon=True).start()


def launch_gui_win(config: Optional[GuardianConfig] = None) -> None:
    app = WifiACGuardianWinUI(config=config)
    app.mainloop()


if __name__ == "__main__":
    launch_gui_win()
