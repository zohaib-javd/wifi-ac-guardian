@echo off
setlocal enabledelayedexpansion

echo ======================================================
echo   Uninstalling WiFi AC Guardian (Windows 11 Edition) 
echo ======================================================

:: 1. Stop processes
taskkill /F /IM wifi-ac-guardian-win.exe >nul 2>&1

:: 2. Remove shortcuts
del /q "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\WiFi AC Guardian.lnk" >nul 2>&1
del /q "%USERPROFILE%\Desktop\WiFi AC Guardian.lnk" >nul 2>&1

:: 3. Uninstall Python package
python -m pip uninstall -y wifi-ac-guardian-win

echo ======================================================
echo    WiFi AC Guardian Uninstalled Successfully.         
echo ======================================================
pause
