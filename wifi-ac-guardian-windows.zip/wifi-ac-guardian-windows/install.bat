@echo off
setlocal enabledelayedexpansion

echo ======================================================
echo    Installing WiFi AC Guardian (Windows 11 Edition)   
echo ======================================================

:: 1. Check Python installation
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo ERROR: Python is not installed or not in PATH.
    echo Please install Python 3.10+ from python.org or Microsoft Store.
    pause
    exit /b 1
)

:: 2. Install Python Package
echo [1/3] Installing Python package and dependencies...
python -m pip install --upgrade .

:: 3. Create Windows Startup Shortcut (Autostart on Logon)
echo [2/3] Configuring Windows Startup shortcut...
set "STARTUP_DIR=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"
set "DESKTOP_DIR=%USERPROFILE%\Desktop"

set "TARGET_CMD=%LOCALAPPDATA%\Programs\Python\Python312\Scripts\wifi-ac-guardian-win.exe"
python -c "import shutil, sys; print(shutil.which('wifi-ac-guardian-win') or sys.executable)" > "%TEMP%\wifi_bin.txt"
set /p EXE_PATH=<"%TEMP%\wifi_bin.txt"

powershell -Command "$s=(New-Object -COM WScript.Shell).CreateShortcut('%STARTUP_DIR%\WiFi AC Guardian.lnk'); $s.TargetPath='%EXE_PATH%'; $s.Arguments='--daemon'; $s.Save()"
powershell -Command "$s=(New-Object -COM WScript.Shell).CreateShortcut('%DESKTOP_DIR%\WiFi AC Guardian.lnk'); $s.TargetPath='%EXE_PATH%'; $s.Arguments='--gui'; $s.Save()"

echo [3/3] Launching WiFi AC Guardian Control Panel...
start "" "%EXE_PATH%" --gui

echo ======================================================
echo  WiFi AC Guardian (Windows 11) Successfully Installed!
echo ======================================================
pause
