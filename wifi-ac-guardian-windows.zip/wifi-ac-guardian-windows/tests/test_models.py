"""Unit tests for Windows models.py."""
import unittest
from wifi_ac_guardian_win.core.models import LinkInfo, PhyMode, GuardianConfig


class TestModelsWin(unittest.TestCase):
    def test_link_info_is_good(self):
        link_vht = LinkInfo(connected=True, phy_mode=PhyMode.VHT)
        self.assertTrue(link_vht.is_good)

        link_he = LinkInfo(connected=True, phy_mode=PhyMode.HE)
        self.assertTrue(link_he.is_good)

        link_ht = LinkInfo(connected=True, phy_mode=PhyMode.HT)
        self.assertFalse(link_ht.is_good)

    def test_guardian_config_defaults(self):
        config = GuardianConfig()
        self.assertEqual(config.check_interval, 10.0)
        self.assertEqual(config.reconnect_delay, 2.0)
        self.assertEqual(config.max_attempts, 10)


if __name__ == "__main__":
    unittest.main()
