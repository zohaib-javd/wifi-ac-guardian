"""Unit tests for Windows netsh wlan output parser."""
import unittest
from wifi_ac_guardian_win.core.models import PhyMode
from wifi_ac_guardian_win.core.detector_win import parse_netsh_output, determine_win_phy_mode


class TestDetectorWin(unittest.TestCase):
    def test_parse_vht_netsh_output(self):
        sample_output = """
    There is 1 interface on the system:

        Name                   : Wi-Fi
        Description            : Intel(R) Wi-Fi 6 AX201 160MHz
        State                  : connected
        SSID                   : HomeNetwork5G
        BSSID                  : 08:5c:1b:17:7d:80
        Network type           : Infrastructure
        Radio type             : 802.11ac
        Authentication         : WPA2-Personal
        Cipher                 : CCMP
        Connection mode        : Auto Connect
        Band                   : 5 GHz
        Channel                : 161
        Receive rate (Mbps)    : 866.7
        Transmit rate (Mbps)   : 866.7
        Signal                 : 95%
"""
        info = parse_netsh_output(sample_output)
        self.assertTrue(info.connected)
        self.assertEqual(info.ssid, "HomeNetwork5G")
        self.assertEqual(info.interface, "Wi-Fi")
        self.assertEqual(info.channel, 161)
        self.assertEqual(info.signal_pct, 95)
        self.assertEqual(info.phy_mode, PhyMode.VHT)
        self.assertTrue(info.is_good)

    def test_parse_ht_netsh_output(self):
        sample_output = """
        Name                   : Wi-Fi
        State                  : connected
        SSID                   : LegacyOffice
        Radio type             : 802.11n
        Band                   : 2.4 GHz
        Channel                : 6
        Transmit rate (Mbps)   : 144.0
        Signal                 : 70%
"""
        info = parse_netsh_output(sample_output)
        self.assertTrue(info.connected)
        self.assertEqual(info.phy_mode, PhyMode.HT)
        self.assertFalse(info.is_good)

    def test_parse_he_wifi6_output(self):
        self.assertEqual(determine_win_phy_mode("802.11ax", ""), PhyMode.HE)

    def test_parse_eht_wifi7_output(self):
        self.assertEqual(determine_win_phy_mode("802.11be", ""), PhyMode.EHT)


if __name__ == "__main__":
    unittest.main()
